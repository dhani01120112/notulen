package com.notulen.app

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/* ---------- data ---------- */
data class Act(val t: String = "", val p: String = "", val d: String = "")
data class Note(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val date: String = today(),
    val people: String = "",
    val notes: String = "",
    val resume: String = "",
    val actions: List<Act> = emptyList(),
)

fun today(): String = SimpleDateFormat("d MMMM yyyy", Locale("id", "ID")).format(Date())

fun Note.hasContent() = title.isNotBlank() || notes.isNotBlank() || resume.isNotBlank() || actions.any { it.t.isNotBlank() }

fun Note.toJson(): JSONObject = JSONObject().put("id", id).put("title", title).put("date", date).put("people", people)
    .put("notes", notes).put("resume", resume)
    .put("actions", JSONArray(actions.map { JSONObject().put("t", it.t).put("p", it.p).put("d", it.d) }))

fun JSONObject.toNote() = Note(
    getString("id"), getString("title"), getString("date"), getString("people"), getString("notes"),
    optString("resume", ""),
    getJSONArray("actions").let { a -> List(a.length()) { i -> a.getJSONObject(i).let { Act(it.getString("t"), it.getString("p"), it.getString("d")) } } },
)

fun Note.toText(): String {
    val b = StringBuilder("NOTULEN RAPAT\n${title.ifBlank { "(Tanpa judul)" }}\nTanggal: $date")
    if (people.isNotBlank()) b.append("\nPeserta: ${people.trim()}")
    if (resume.isNotBlank()) b.append("\n\nRESUME\n${resume.trim()}")
    if (notes.isNotBlank()) b.append("\n\nCATATAN\n${notes.trim()}")
    val ac = actions.filter { it.t.isNotBlank() }
    if (ac.isNotEmpty()) {
        b.append("\n\nTINDAK LANJUT")
        ac.forEach { b.append("\n- ${it.t.trim()}" + (if (it.p.isNotBlank()) " | PIC: ${it.p.trim()}" else "") + (if (it.d.isNotBlank()) " | Tenggat: ${it.d.trim()}" else "")) }
    }
    return b.toString()
}

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("notulen", Context.MODE_PRIVATE)
    fun history(): List<Note> = runCatching {
        JSONArray(sp.getString("hist", "[]")).let { a -> List(a.length()) { a.getJSONObject(it).toNote() } }
    }.getOrDefault(emptyList())
    fun saveHistory(l: List<Note>) = sp.edit().putString("hist", JSONArray(l.map { it.toJson() }).toString()).apply()
    fun draft(): Note = runCatching { JSONObject(sp.getString("draft", "")!!).toNote() }.getOrDefault(Note())
    fun saveDraft(n: Note) = sp.edit().putString("draft", n.toJson().toString()).apply()
}

/* ---------- resume tanpa API key ---------- */
private val STOP = setOf("yang","dan","di","ke","dari","untuk","pada","dengan","ini","itu","adalah","akan","atau","juga","saya","kami","kita","anda","kamu","dia","mereka","ada","tidak","bisa","sudah","belum","jadi","karena","agar","supaya","sebagai","dalam","oleh","bahwa","lebih","saja","kan","dong","sih","nah","apa","kalau","jika","nanti","tadi","lagi","sama","para","tapi","tetapi","namun","pun")
private val CUE = setOf("sepakat","disepakati","diputuskan","keputusan","target","tenggat","deadline","harus","penting","masalah","kendala","rencana","anggaran","jadwal","prioritas","hasil","evaluasi")

val PROMPT_RESUME = listOf(
    "Kamu notulis rapat. Buat resume dalam Bahasa Indonesia dari notulen di bawah, dalam teks biasa tanpa markdown dan tanpa tabel, dengan format:",
    "Ringkasan: 2-4 kalimat.",
    "Poin utama: daftar bertanda \"-\" (maksimal 7).",
    "Keputusan: daftar bertanda \"-\" (tulis \"Tidak ada\" bila kosong).",
    "Tindak lanjut: daftar bertanda \"-\" lengkap dengan penanggung jawab dan tenggat bila ada (tulis \"Tidak ada\" bila kosong).",
    "Pakai hanya informasi dari notulen dan jangan menambah fakta. Catatan berasal dari rekam suara, jadi perbaiki salah dengar yang jelas tanpa mengubah makna. Abaikan tanda waktu.",
).joinToString("\n")

/** Resume offline: memilih kalimat terpenting dari catatan (berdasarkan kata yang sering muncul dan kata kunci rapat). */
fun resumeLokal(n: Note): String {
    val kata = { s: String -> Regex("[\\p{L}\\p{N}]+").findAll(s.lowercase()).map { it.value }.filter { it.length > 2 && it !in STOP }.toList() }
    val kal = n.notes.lines()
        .map { it.replace(Regex("^\\[\\d\\d:\\d\\d\\]\\s*"), "").trim() }
        .flatMap { it.split(Regex("(?<=[.!?])\\s+")) }
        .map { it.trim() }
        .filter { it.split(Regex("\\s+")).size >= 4 }
    val b = StringBuilder()
    if (kal.isNotEmpty()) {
        val freq = kal.flatMap { kata(it) }.groupingBy { it }.eachCount()
        val skor = kal.map { u ->
            val w = kata(u)
            if (w.isEmpty()) 0.0 else w.sumOf { freq[it] ?: 0 }.toDouble() / w.size + 3.0 * w.count { it in CUE }
        }
        val top = (kal.size / 4).coerceIn(3, 7).coerceAtMost(kal.size)
        val dipilih = skor.withIndex().sortedByDescending { it.value }.take(top).map { it.index }.sorted()
        b.append("Poin utama:")
        dipilih.forEach { b.append("\n- ").append(kal[it].trimEnd('.', ' ')) }
    }
    val ac = n.actions.filter { it.t.isNotBlank() }
    if (ac.isNotEmpty()) {
        if (b.isNotEmpty()) b.append("\n\n")
        b.append("Tindak lanjut:")
        ac.forEach {
            b.append("\n- ").append(it.t.trim())
                .append(if (it.p.isNotBlank()) " | PIC: ${it.p.trim()}" else "")
                .append(if (it.d.isNotBlank()) " | Tenggat: ${it.d.trim()}" else "")
        }
    }
    return b.toString()
}

/* ---------- rekam suara (Bahasa Indonesia) ---------- */
class Dictation(
    private val ctx: Context,
    private val onPartial: (String) -> Unit,
    private val onFinal: (String) -> Unit,
    private val onMsg: (String) -> Unit,
) {
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    // Membisukan suara "tung" saat mikrofon menyala/mati ulang. Volume media dikembalikan saat rekaman berhenti.
    private fun quiet(on: Boolean) {
        runCatching { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (on) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE, 0) }
    }
    var active by mutableStateOf(false)
        private set

    private val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        // Beri jeda diam lebih panjang supaya sesi tidak cepat berhenti (tidak semua mesin suara mengikutinya)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 6000L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 6000L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 60000L)
    }

    private fun first(b: android.os.Bundle?) = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: android.os.Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, b: android.os.Bundle?) {}
        override fun onPartialResults(b: android.os.Bundle?) = onPartial(first(b))
        override fun onResults(b: android.os.Bundle?) {
            onPartial("")
            val t = first(b).trim()
            if (t.isNotEmpty()) onFinal(t)
            again()
        }
        override fun onError(e: Int) {
            onPartial("")
            when (e) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> again()
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> again(800)
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { stop(); onMsg("Izin mikrofon belum diberikan.") }
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> { stop(); onMsg("Pengenalan suara butuh internet. Periksa koneksimu, lalu coba lagi.") }
                else -> { stop(); onMsg("Rekam suara bermasalah (kode $e). Coba lagi.") }
            }
        }
    }

    private fun again(delay: Long = 100) {
        if (active) h.postDelayed({ if (active) sr?.startListening(intent) }, delay)
    }

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onMsg("Layanan pengenalan suara tidak ditemukan. Pastikan aplikasi Google terpasang dan aktif.")
            return
        }
        active = true
        quiet(true)
        sr = SpeechRecognizer.createSpeechRecognizer(ctx).also { it.setRecognitionListener(listener); it.startListening(intent) }
        onMsg("Mendengarkan… bicara dalam Bahasa Indonesia.")
    }

    fun stop() {
        active = false
        quiet(false)
        h.removeCallbacksAndMessages(null)
        sr?.destroy(); sr = null
        onPartial("")
    }
}

/* ---------- UI ---------- */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var note by remember { mutableStateOf(store.draft()) }
    var hist by remember { mutableStateOf(store.history()) }
    var tab by remember { mutableIntStateOf(0) }
    var partial by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("Tekan “Rekam suara” untuk mencatat lewat ucapan, atau ketik langsung.") }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    fun toast(s: String) { scope.launch { snack.showSnackbar(s) } }

    val dict = remember {
        Dictation(ctx, { partial = it }, { t ->
            val jam = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            val sep = if (note.notes.isEmpty() || note.notes.endsWith("\n")) "" else "\n"
            note = note.copy(notes = note.notes + sep + "[$jam] $t\n")
        }, { msg = it })
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) dict.start() else msg = "Izin mikrofon ditolak. Buka Pengaturan > Aplikasi > Notulen Rapat > Izin, lalu izinkan Mikrofon."
    }
    DisposableEffect(Unit) { onDispose { dict.stop() } }
    LaunchedEffect(note) { store.saveDraft(note) }

    fun toggleMic() {
        if (dict.active) { dict.stop(); msg = "Rekaman berhenti. Tekan “Rekam suara” untuk lanjut." }
        else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) dict.start()
        else perm.launch(Manifest.permission.RECORD_AUDIO)
    }
    fun share(n: Note) {
        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, n.title); putExtra(Intent.EXTRA_TEXT, n.toText())
        }, "Bagikan notulen"))
    }
    fun save(quiet: Boolean): Boolean {
        if (!note.hasContent()) { if (!quiet) toast("Isi dulu catatan atau judul rapat"); return false }
        val n = if (note.title.isBlank()) note.copy(title = "Rapat ${note.date}") else note
        note = n
        hist = listOf(n) + hist.filter { it.id != n.id }
        store.saveHistory(hist)
        if (!quiet) toast("Notulen tersimpan")
        return true
    }

    fun adaIsi() = note.notes.isNotBlank() || note.actions.any { it.t.isNotBlank() }
    fun resumeCepat() {
        if (!adaIsi()) { toast("Isi catatan dulu, lalu buat resume"); return }
        note = note.copy(resume = resumeLokal(note))
        toast("Resume dibuat. Kamu bisa mengeditnya.")
    }
    fun kirimKeAI() {
        if (!adaIsi()) { toast("Isi catatan dulu, lalu kirim"); return }
        val teks = PROMPT_RESUME + "\n\nNotulen:\n" + note.copy(resume = "").toText()
        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, teks)
        }, "Kirim ke Claude atau AI lain"))
    }
    fun tempelHasil() {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty().trim()
        if (t.isEmpty()) toast("Clipboard kosong. Salin jawaban AI dulu.") else { note = note.copy(resume = t); toast("Resume ditempel") }
    }

    Scaffold(snackbarHost = { SnackbarHost(snack) }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().imePadding()) {
            Text("Notulen Rapat", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp))
            TabRow(selectedTabIndex = tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text("Rapat") })
                Tab(tab == 1, { tab = 1 }, text = { Text("Riwayat (${hist.size})") })
            }
            if (tab == 0) {
                Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(note.title, { note = note.copy(title = it) }, Modifier.fillMaxWidth(), label = { Text("Judul rapat") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(note.date, { note = note.copy(date = it) }, Modifier.weight(1f), label = { Text("Tanggal") }, singleLine = true)
                        OutlinedTextField(note.people, { note = note.copy(people = it) }, Modifier.weight(1f), label = { Text("Peserta") }, singleLine = true)
                    }
                    Button(
                        { toggleMic() }, Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = if (dict.active) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary),
                    ) { Text(if (dict.active) "Berhenti merekam" else "Rekam suara") }
                    Text(msg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (partial.isNotEmpty()) Text(partial, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                    OutlinedTextField(note.notes, { note = note.copy(notes = it) }, Modifier.fillMaxWidth(), label = { Text("Catatan") }, minLines = 8)

                    Text("Resume", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        note.resume, { note = note.copy(resume = it) }, Modifier.fillMaxWidth(),
                        placeholder = { Text("Buat otomatis dengan tombol di bawah, atau tulis sendiri") }, minLines = 4,
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ resumeCepat() }, Modifier.weight(1f)) { Text("Resume cepat") }
                        OutlinedButton({ tempelHasil() }, Modifier.weight(1f)) { Text("Tempel hasil") }
                    }
                    OutlinedButton({ kirimKeAI() }, Modifier.fillMaxWidth()) { Text("Kirim ke Claude / AI lain") }
                    Text(
                        "Resume cepat bekerja offline. Untuk hasil yang lebih rapi, kirim ke Claude, salin jawabannya, lalu tekan “Tempel hasil”.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Tindak lanjut", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        TextButton({ note = note.copy(actions = note.actions + Act()) }) { Text("Tambah") }
                    }
                    note.actions.forEachIndexed { i, a ->
                        fun set(n: Act) { note = note.copy(actions = note.actions.toMutableList().also { it[i] = n }) }
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(a.t, { set(a.copy(t = it)) }, Modifier.fillMaxWidth(), label = { Text("Tugas") })
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(a.p, { set(a.copy(p = it)) }, Modifier.weight(1f), label = { Text("Penanggung jawab") }, singleLine = true)
                                    OutlinedTextField(a.d, { set(a.copy(d = it)) }, Modifier.weight(1f), label = { Text("Tenggat") }, singleLine = true)
                                }
                                TextButton({ note = note.copy(actions = note.actions.filterIndexed { j, _ -> j != i }) }) { Text("Hapus tugas") }
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ save(false) }) { Text("Simpan") }
                        OutlinedButton({ if (note.hasContent()) share(note) else toast("Belum ada isi untuk dibagikan") }) { Text("Bagikan") }
                        OutlinedButton({
                            dict.stop()
                            val saved = save(true)
                            note = Note()
                            toast(if (saved) "Rapat sebelumnya tersimpan. Rapat baru siap." else "Rapat baru siap")
                        }) { Text("Rapat baru") }
                    }
                }
            } else {
                Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (hist.isEmpty()) Text("Belum ada notulen tersimpan. Tekan “Simpan” setelah rapat selesai.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    hist.forEach { n ->
                        HistoryItem(n,
                            onOpen = { dict.stop(); note = n; tab = 0 },
                            onShare = { share(n) },
                            onDelete = { hist = hist.filter { it.id != n.id }; store.saveHistory(hist); toast("Notulen dihapus") })
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryItem(n: Note, onOpen: () -> Unit, onShare: () -> Unit, onDelete: () -> Unit) {
    var armed by remember { mutableStateOf(false) }
    val snippet = n.notes.replace(Regex("\\[\\d\\d:\\d\\d\\]\\s*"), "").replace(Regex("\\s+"), " ").trim().ifEmpty { "Tanpa catatan" }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(n.title.ifBlank { "(Tanpa judul)" }, style = MaterialTheme.typography.titleMedium)
            Text("${n.date} – $snippet", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            Row {
                TextButton(onOpen) { Text("Buka") }
                TextButton(onShare) { Text("Bagikan") }
                TextButton({ if (armed) onDelete() else armed = true }) { Text(if (armed) "Yakin hapus?" else "Hapus") }
            }
        }
    }
}
